main()
{
printf("a string\n!");
}