#define MAXIDLEN 20
struct identifier{char id[MAXIDLEN];} ;
