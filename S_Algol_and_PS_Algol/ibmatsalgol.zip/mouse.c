#include "crtlib.c"
main()
{   MOUSESHOW();
	printf("%d %d",MOUSEPRES(), MOUSEX());

}