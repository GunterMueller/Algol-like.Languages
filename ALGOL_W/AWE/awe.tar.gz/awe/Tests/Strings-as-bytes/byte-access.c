int byte (unsigned char s) { return (int)s; }
unsigned char debyte (int x) { return (unsigned char)( x % 256); }
