(* options.ml --- Awe compiler options. *)

let initialize_all = ref false
let add_tracing_hooks = ref false
